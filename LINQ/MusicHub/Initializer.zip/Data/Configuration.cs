﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-30287UE\SQLEXPRESS;Database=MusicHub;Integrated Security=True";
    }
}
